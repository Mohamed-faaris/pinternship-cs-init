interface SectionTitleProps {
  title: string
}

function SectionTitle({ title }: SectionTitleProps) {
  return <h3>{title}</h3>
}

export default SectionTitle
