import { useReducer, useState } from 'react'
import type { BudgetAction, BudgetState, ConversionRates, Currency } from '../types/budget'

const conversionRates: ConversionRates = {
  USD: 1,
  INR: 83,
  EUR: 0.92,
}

const initialState: BudgetState = {
  income: 0,
  expenses: 0,
  currency: 'USD',
}

function reducer(state: BudgetState, action: BudgetAction): BudgetState {
  switch (action.type) {
    case 'ADD_INCOME':
      return { ...state, income: state.income + action.amount }
    case 'ADD_EXPENSE': {
      const nextExpenses = state.expenses + action.amount
      if (nextExpenses > state.income) {
        return state
      }
      return { ...state, expenses: nextExpenses }
    }
    case 'SET_CURRENCY':
      return { ...state, currency: action.currency }
    default:
      return state
  }
}

function BudgetTracker() {
  const [state, dispatch] = useReducer(reducer, initialState)
  const [incomeInput, setIncomeInput] = useState('')
  const [expenseInput, setExpenseInput] = useState('')

  const netBalance = state.income - state.expenses
  const convertedBalance = netBalance * conversionRates[state.currency]

  const addIncome = () => {
    const amount = Number(incomeInput)
    if (!Number.isNaN(amount) && amount > 0) {
      dispatch({ type: 'ADD_INCOME', amount })
      setIncomeInput('')
    }
  }

  const addExpense = () => {
    const amount = Number(expenseInput)
    if (!Number.isNaN(amount) && amount > 0) {
      dispatch({ type: 'ADD_EXPENSE', amount })
      setExpenseInput('')
    }
  }

  const setCurrency = (currency: Currency) => {
    dispatch({ type: 'SET_CURRENCY', currency })
  }

  return (
    <section>
      <h3>Budget Tracker</h3>
      <p>Income: ${state.income.toFixed(2)}</p>
      <p>Expenses: ${state.expenses.toFixed(2)}</p>
      <p>Net Balance: ${netBalance.toFixed(2)}</p>
      <p>
        Net Balance ({state.currency}): {convertedBalance.toFixed(2)}
      </p>

      <div>
        <input
          placeholder="Add income"
          type="number"
          value={incomeInput}
          onChange={(event) => setIncomeInput(event.target.value)}
        />
        <button type="button" onClick={addIncome}>
          Add Income
        </button>
      </div>

      <div>
        <input
          placeholder="Add expense"
          type="number"
          value={expenseInput}
          onChange={(event) => setExpenseInput(event.target.value)}
        />
        <button type="button" onClick={addExpense}>
          Add Expense
        </button>
      </div>

      <div>
        <button type="button" onClick={() => setCurrency('USD')}>
          USD
        </button>
        <button type="button" onClick={() => setCurrency('INR')}>
          INR
        </button>
        <button type="button" onClick={() => setCurrency('EUR')}>
          EUR
        </button>
      </div>
      {state.expenses > state.income && <p>Negative balance is not allowed.</p>}
    </section>
  )
}

export default BudgetTracker
