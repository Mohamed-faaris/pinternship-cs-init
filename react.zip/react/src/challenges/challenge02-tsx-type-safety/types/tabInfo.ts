export interface NestedTab {
  label: string
  path: string
}
