export type Currency = 'USD' | 'INR' | 'EUR'

export interface ConversionRates {
  USD: number
  INR: number
  EUR: number
}

export interface BudgetState {
  income: number
  expenses: number
  currency: Currency
}

export type BudgetAction =
  | { type: 'ADD_INCOME'; amount: number }
  | { type: 'ADD_EXPENSE'; amount: number }
  | { type: 'SET_CURRENCY'; currency: Currency }
