import { Link, Outlet } from 'react-router-dom'

function NestedLayoutPage() {
  return (
    <main>
      <h2>Challenge 2: Nested routes</h2>
      <nav>
        <Link to="dashboard">Dashboard</Link> | <Link to="profile">Profile</Link> |{' '}
        <Link to="settings">Settings</Link>
      </nav>
      <hr />
      <Outlet />
      <p>
        <Link to="/">Back to Home</Link>
      </p>
    </main>
  )
}

export default NestedLayoutPage
