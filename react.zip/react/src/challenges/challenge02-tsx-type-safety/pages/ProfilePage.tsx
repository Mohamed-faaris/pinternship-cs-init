import SectionTitle from '../components/SectionTitle'

function ProfilePage() {
  return (
    <section>
      <SectionTitle title="Profile" />
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit, cupiditate reprehenderit repellendus sit consequuntur nulla commodi illo doloremque culpa aliquam exercitationem excepturi voluptatum quasi repellat! Illum similique repellat architecto natus!</p>
    </section>
  )
}

export default ProfilePage
