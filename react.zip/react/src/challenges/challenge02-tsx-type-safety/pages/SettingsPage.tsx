import SectionTitle from '../components/SectionTitle'

function SettingsPage() {
  return (
    <section>
      <SectionTitle title="Settings" />
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum tempora, praesentium dolore minus iste delectus deserunt quae. Adipisci quidem sint similique, voluptas voluptatibus minus quisquam, qui quibusdam, molestiae ipsam sed.</p>
    </section>
  )
}

export default SettingsPage
