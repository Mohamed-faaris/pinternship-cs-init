import SectionTitle from '../components/SectionTitle'

function DashboardPage() {
  return (
    <section>
      <SectionTitle title="Dashboard" />
      <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Deleniti dolorem officiis quisquam nulla. Natus ut, incidunt sit quo voluptas reprehenderit amet illum totam! Ut quaerat blanditiis ipsam quas aspernatur fugiat?</p>
    </section>
  )
}

export default DashboardPage
