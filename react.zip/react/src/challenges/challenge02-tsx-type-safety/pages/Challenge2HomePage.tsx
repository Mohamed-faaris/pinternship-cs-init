import { Link } from 'react-router-dom'
import BudgetTracker from '../components/BudgetTracker'

function Challenge2HomePage() {
  return (
    <main>
      <h2>Challenge 2: Type Safety</h2>
      <BudgetTracker />
      <p>
        <Link to="/">Back to Home</Link>
      </p>
    </main>
  )
}

export default Challenge2HomePage
