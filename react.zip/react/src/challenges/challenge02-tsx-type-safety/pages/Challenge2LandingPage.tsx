function Challenge2LandingPage() {
  return <p>Select a nested page from the navigation above.</p>
}

export default Challenge2LandingPage
