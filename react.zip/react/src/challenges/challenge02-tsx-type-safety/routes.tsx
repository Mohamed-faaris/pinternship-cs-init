import { Route, Routes } from 'react-router-dom'
import Challenge2HomePage from './pages/Challenge2HomePage'

function Challenge2Routes() {
  return (
    <Routes>
      <Route path="/" element={<Challenge2HomePage />} />
    </Routes>
  )
}

export default Challenge2Routes
