function SafePage() {
  return (
    <main>
      <h3>Safe route</h3>
      <p>No error here.</p>
    </main>
  )
}

export default SafePage
