import { useState } from 'react'

function CrashPage() {
  const [shouldCrash, setShouldCrash] = useState(false)

  if (shouldCrash) {
    throw new Error('Intentional route error')
  }

  return (
    <main>
      <h3>Crash route</h3>
      <button type="button" onClick={() => setShouldCrash(true)}>
        Trigger render error
      </button>
    </main>
  )
}

export default CrashPage
