import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import CollaboratorsQuery from '../components/CollaboratorsQuery'
import { useHistoryStore } from '../store/useHistoryStore'
import { useSessionStore } from '../store/useSessionStore'

const queryClient = new QueryClient()

function Challenge7HomePage() {
  const { userId, token, role, setSession, clearSession } = useSessionStore()
  const { entries, addHistoryEntry, clearHistory } = useHistoryStore()

  return (
    <main>
      <h2>Challenge 7: Advanced Zustand</h2>
      <p>User: {userId ?? 'none'}</p>
      <p>Token: {token ?? 'none'}</p>
      <p>Role: {role}</p>
      <button
        type="button"
        onClick={() => {
          setSession({ userId: 'u-101', token: 'token-xyz', expiresAt: Date.now() + 3600000, role: 'admin' })
          addHistoryEntry('Session initialized')
        }}
      >
        Set Session
      </button>
      <button
        type="button"
        onClick={() => {
          clearSession()
          addHistoryEntry('Session cleared')
        }}
      >
        Clear Session
      </button>

      <h3>History Log</h3>
      <button type="button" onClick={() => addHistoryEntry('Manual history entry')}>
        Add History Entry
      </button>
      <button type="button" onClick={clearHistory}>
        Clear History
      </button>
      <ul>
        {entries.map((entry) => (
          <li key={entry.id}>{entry.description}</li>
        ))}
      </ul>

      <QueryClientProvider client={queryClient}>
        <CollaboratorsQuery />
      </QueryClientProvider>

      <p>
        <Link to="/">Back to Home</Link>
      </p>
    </main>
  )
}

export default Challenge7HomePage
