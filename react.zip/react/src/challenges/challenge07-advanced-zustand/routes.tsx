import { Route, Routes } from 'react-router-dom'
import Challenge7HomePage from './pages/Challenge7HomePage'

function Challenge7Routes() {
  return (
    <Routes>
      <Route path="/" element={<Challenge7HomePage />} />
    </Routes>
  )
}

export default Challenge7Routes
