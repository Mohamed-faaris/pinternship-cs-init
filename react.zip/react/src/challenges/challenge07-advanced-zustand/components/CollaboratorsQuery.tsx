import { useEffect } from 'react'
import { useQuery } from '@tanstack/react-query'
import { useCollaboratorStore } from '../store/useCollaboratorStore'
import type { Collaborator } from '../types/collaborator'

async function fetchCollaborators(): Promise<Collaborator[]> {
  const response = await fetch('https://jsonplaceholder.typicode.com/users?_limit=5')
  if (!response.ok) {
    throw new Error('Failed to fetch collaborators')
  }
  const data = (await response.json()) as Collaborator[]
  return data
}

function CollaboratorsQuery() {
  const setCollaborators = useCollaboratorStore((state) => state.setCollaborators)
  const collaborators = useCollaboratorStore((state) => state.collaborators)

  const query = useQuery({
    queryKey: ['collaborators'],
    queryFn: fetchCollaborators,
  })

  useEffect(() => {
    if (query.data) {
      setCollaborators(query.data)
    }
  }, [query.data, setCollaborators])

  if (query.isLoading) {
    return <p>Loading collaborators...</p>
  }

  if (query.error) {
    return <p>Failed to load collaborators.</p>
  }

  return (
    <section>
      <h3>Collaborators</h3>
      <ul>
        {collaborators.map((item) => (
          <li key={item.id}>
            {item.name} - {item.email}
          </li>
        ))}
      </ul>
    </section>
  )
}

export default CollaboratorsQuery
