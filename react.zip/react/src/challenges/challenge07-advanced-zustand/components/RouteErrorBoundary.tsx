import { Component } from 'react'
import type { RouteErrorBoundaryProps, RouteErrorBoundaryState } from '../types/errorBoundary'

class RouteErrorBoundary extends Component<RouteErrorBoundaryProps, RouteErrorBoundaryState> {
  public constructor(props: RouteErrorBoundaryProps) {
    super(props)
    this.state = { hasError: false }
  }

  public static getDerivedStateFromError(): RouteErrorBoundaryState {
    return { hasError: true }
  }

  public render() {
    if (this.state.hasError) {
      return (
        <main>
          <h3>Route Error Boundary</h3>
          <p>This route crashed, and the route-level boundary handled it.</p>
        </main>
      )
    }

    return this.props.children
  }
}

export default RouteErrorBoundary
