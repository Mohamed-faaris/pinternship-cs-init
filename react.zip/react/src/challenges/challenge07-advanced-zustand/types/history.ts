export interface HistoryEntry {
  id: string
  description: string
  at: number
}

export interface HistoryStore {
  entries: HistoryEntry[]
  addHistoryEntry: (description: string) => void
  clearHistory: () => void
}
