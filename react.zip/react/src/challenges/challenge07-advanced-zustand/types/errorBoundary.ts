import type { ReactNode } from 'react'

export interface RouteErrorBoundaryProps {
  children: ReactNode
}

export interface RouteErrorBoundaryState {
  hasError: boolean
}
