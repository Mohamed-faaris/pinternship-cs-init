export type UserRole = 'admin' | 'user'

export interface SessionState {
  userId: string | null
  token: string | null
  expiresAt: number | null
  role: UserRole
  setSession: (session: { userId: string; token: string; expiresAt: number; role?: UserRole }) => void
  clearSession: () => void
}
