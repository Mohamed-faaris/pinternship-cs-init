import { create } from 'zustand'
import type { Collaborator } from '../types/collaborator'

interface CollaboratorStore {
  collaborators: Collaborator[]
  setCollaborators: (items: Collaborator[]) => void
}

export const useCollaboratorStore = create<CollaboratorStore>((set) => ({
  collaborators: [],
  setCollaborators: (items) => set({ collaborators: items }),
}))
