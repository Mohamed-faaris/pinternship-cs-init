import { create } from 'zustand'
import { devtools } from 'zustand/middleware'
import { immer } from 'zustand/middleware/immer'
import type { HistoryStore } from '../types/history'

export const useHistoryStore = create<HistoryStore>()(
  devtools(
    immer((set) => ({
      entries: [],
      addHistoryEntry: (description) =>
        set((state) => {
          state.entries.push({ id: crypto.randomUUID(), description, at: Date.now() })
        }),
      clearHistory: () =>
        set((state) => {
          state.entries = []
        }),
    })),
    { name: 'history-store' },
  ),
)
