import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { SessionState } from '../types/session'

export const useSessionStore = create<SessionState>()(
  persist(
    (set) => ({
      userId: null,
      token: null,
      expiresAt: null,
      role: 'user',
      setSession: ({ userId, token, expiresAt, role }) => set({ userId, token, expiresAt, role: role ?? 'user' }),
      clearSession: () => set({ userId: null, token: null, expiresAt: null, role: 'user' }),
    }),
    {
      name: 'advanced-session',
      version: 2,
      partialize: (state) => ({ userId: state.userId, token: state.token }),
      migrate: (persistedState, version) => {
        const state = persistedState as Partial<SessionState>
        if (version < 2) {
          return {
            userId: state.userId ?? null,
            token: state.token ?? null,
            expiresAt: null,
            role: 'user',
            setSession: () => undefined,
            clearSession: () => undefined,
          } as SessionState
        }

        return {
          userId: state.userId ?? null,
          token: state.token ?? null,
          expiresAt: state.expiresAt ?? null,
          role: state.role ?? 'user',
          setSession: () => undefined,
          clearSession: () => undefined,
        } as SessionState
      },
    },
  ),
)
