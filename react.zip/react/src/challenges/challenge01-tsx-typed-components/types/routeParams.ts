export interface DoctorPatientParams {
  [key: string]: string | undefined
  doctorId: string
  patientId: string
}
