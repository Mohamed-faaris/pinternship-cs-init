import { useState } from 'react'
import { Link } from 'react-router-dom'
import AssetEditor from '../components/AssetEditor'
import PortfolioSummary from '../components/PortfolioSummary'
import type { Asset } from '../types/asset'

const initialAssets: Asset[] = [
  { name: 'Apple', symbol: 'AAPL', value: 220.2, change: 1.2 },
  { name: 'Microsoft', symbol: 'MSFT', value: 340.1, change: -0.4 },
]

function Challenge1Home() {
  const [assets, setAssets] = useState<Asset[]>(initialAssets)

  const handleUpdate = (asset: Asset) => {
    setAssets((current) => [...current, asset])
  }

  return (
    <main>
      <h2>Challenge 1: TSX & Typed Components</h2>
      <PortfolioSummary assets={assets} />
      <AssetEditor onUpdate={handleUpdate} />
      <ul>
        {assets.map((asset) => (
          <li key={`${asset.symbol}-${asset.name}-${asset.value}`}>
            {asset.name} ({asset.symbol}) - ${asset.value.toFixed(2)} ({asset.change.toFixed(2)}%)
          </li>
        ))}
      </ul>
      <p>
        <Link to="/">Back to Home</Link>
      </p>
    </main>
  )
}

export default Challenge1Home
