import { Link, useParams } from 'react-router-dom'
import ParamError from '../components/ParamError'
import type { DoctorPatientParams } from '../types/routeParams'

function isValidPositiveInteger(value: string): boolean {
  const parsed = Number(value)
  return Number.isInteger(parsed) && parsed > 0
}

function DoctorPatientPage() {
  const { doctorId, patientId } = useParams<DoctorPatientParams>()

  if (!doctorId || !patientId) {
    return <ParamError message="Missing doctorId or patientId in route." />
  }

  if (!isValidPositiveInteger(doctorId) || !isValidPositiveInteger(patientId)) {
    return <ParamError message="doctorId and patientId must both be positive integers." />
  }

  return (
    <main>
      <h3>Doctor / Patient Route</h3>
      <p>Doctor ID: {doctorId}</p>
      <p>Patient ID: {patientId}</p>
      <p>
        <Link to="/challenge01">Back to Challenge 1</Link>
      </p>
    </main>
  )
}

export default DoctorPatientPage

