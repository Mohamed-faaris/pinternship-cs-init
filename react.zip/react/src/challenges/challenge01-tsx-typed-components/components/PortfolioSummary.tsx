import type { Asset } from '../types/asset'

interface PortfolioSummaryProps {
  assets: Asset[]
}

function PortfolioSummary({ assets }: PortfolioSummaryProps) {
  const totalValue = assets.reduce((sum, asset) => sum + asset.value, 0)
  const averageChange =
    assets.length === 0
      ? 0
      : assets.reduce((sum, asset) => sum + asset.change, 0) / assets.length

  return (
    <section>
      <h3>Portfolio Summary</h3>
      <p>Total Value: ${totalValue.toFixed(2)}</p>
      <p>Average Percentage Change: {averageChange.toFixed(2)}%</p>
    </section>
  )
}

export default PortfolioSummary
