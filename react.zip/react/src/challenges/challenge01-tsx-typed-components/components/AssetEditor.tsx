import { Component, type ChangeEvent, type FormEvent } from 'react'
import type { Asset } from '../types/asset'

interface AssetEditorProps {
  onUpdate: (asset: Asset) => void
}

interface AssetEditorState {
  name: string
  symbol: string
  value: string
  change: string
}

class AssetEditor extends Component<AssetEditorProps, AssetEditorState> {
  public state: AssetEditorState = {
    name: '',
    symbol: '',
    value: '',
    change: '',
  }

  private handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = event.target
    this.setState({ [name]: value } as Pick<AssetEditorState, keyof AssetEditorState>)
  }

  private handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()

    const value = Number(this.state.value)
    const change = Number(this.state.change)

    if (!this.state.name.trim() || !this.state.symbol.trim() || Number.isNaN(value) || Number.isNaN(change)) {
      return
    }

    this.props.onUpdate({
      name: this.state.name.trim(),
      symbol: this.state.symbol.trim().toUpperCase(),
      value,
      change,
    })

    this.setState({
      name: '',
      symbol: '',
      value: '',
      change: '',
    })
  }

  public render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <h3>Asset Editor</h3>
        <input name="name" placeholder="Name" value={this.state.name} onChange={this.handleChange} />
        <input name="symbol" placeholder="Symbol" value={this.state.symbol} onChange={this.handleChange} />
        <input
          name="value"
          type="number"
          step="0.01"
          placeholder="Value"
          value={this.state.value}
          onChange={this.handleChange}
        />
        <input
          name="change"
          type="number"
          step="0.01"
          placeholder="Change %"
          value={this.state.change}
          onChange={this.handleChange}
        />
        <button type="submit">Save Asset</button>
      </form>
    )
  }
}

export default AssetEditor
