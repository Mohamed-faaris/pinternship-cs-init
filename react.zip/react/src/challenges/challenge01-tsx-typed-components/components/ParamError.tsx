interface ParamErrorProps {
  message: string
}

function ParamError({ message }: ParamErrorProps) {
  return (
    <section>
      <h3>Invalid route parameters</h3>
      <p>{message}</p>
    </section>
  )
}

export default ParamError
