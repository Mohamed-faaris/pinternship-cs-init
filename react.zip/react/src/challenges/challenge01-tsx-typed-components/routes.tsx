import { Route, Routes } from 'react-router-dom'
import Challenge1Home from './pages/Challenge1Home'

function Challenge1Routes() {
  return (
    <Routes>
      <Route path="/" element={<Challenge1Home />} />
    </Routes>
  )
}

export default Challenge1Routes
