import { useState } from 'react'
import type { CommentBoxProps } from '../types/comment'

function CommentBox({ onPost }: CommentBoxProps) {
  const [value, setValue] = useState('')

  const handlePost = () => {
    const trimmed = value.trim()
    if (!trimmed) {
      return
    }

    onPost(trimmed)
    setValue('')
  }

  return (
    <section>
      <h3>Comment Box</h3>
      <input
        aria-label="comment-input"
        value={value}
        onChange={(event) => setValue(event.target.value)}
        placeholder="Write a comment"
      />
      <button type="button" onClick={handlePost}>
        Post
      </button>
    </section>
  )
}

export default CommentBox
