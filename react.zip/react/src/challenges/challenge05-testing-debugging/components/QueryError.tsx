interface QueryErrorProps {
  message: string
}

function QueryError({ message }: QueryErrorProps) {
  return (
    <section>
      <h3>Invalid query parameters</h3>
      <p>{message}</p>
    </section>
  )
}

export default QueryError
