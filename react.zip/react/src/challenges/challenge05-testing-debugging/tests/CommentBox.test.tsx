import { fireEvent, render, screen } from '@testing-library/react'
import { describe, expect, it, vi } from 'vitest'
import CommentBox from '../components/CommentBox'

describe('CommentBox', () => {
  it('supports typing, posting, callback execution, and input clearing', () => {
    const onPost = vi.fn()
    render(<CommentBox onPost={onPost} />)

    const input = screen.getByLabelText('comment-input') as HTMLInputElement
    const button = screen.getByRole('button', { name: 'Post' })

    fireEvent.change(input, { target: { value: 'Approved!' } })
    expect(input.value).toBe('Approved!')

    fireEvent.click(button)

    expect(onPost).toHaveBeenCalledTimes(1)
    expect(onPost).toHaveBeenCalledWith('Approved!')
    expect(input.value).toBe('')
  })
})
