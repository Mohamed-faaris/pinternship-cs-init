import { Route, Routes } from 'react-router-dom'
import Challenge5HomePage from './pages/Challenge5HomePage'

function Challenge5Routes() {
  return (
    <Routes>
      <Route path="/" element={<Challenge5HomePage />} />
    </Routes>
  )
}

export default Challenge5Routes
