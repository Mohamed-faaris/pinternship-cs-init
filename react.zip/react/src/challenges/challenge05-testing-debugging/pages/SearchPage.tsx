import { Link, useSearchParams } from 'react-router-dom'
import QueryError from '../components/QueryError'
import type { SearchQueryParams } from '../types/queryParams'

type SortOrder = 'asc' | 'desc'

function isPositiveInt(input: string): boolean {
  const num = Number(input)
  return Number.isInteger(num) && num > 0
}

function isSortOrder(input: string): input is SortOrder {
  return input === 'asc' || input === 'desc'
}

function SearchPage() {
  const [searchParams] = useSearchParams()

  const params: SearchQueryParams = {
    term: searchParams.get('term') ?? '',
    page: searchParams.get('page') ?? '',
    sort: searchParams.get('sort') ?? '',
  }

  if (!params.term) {
    return <QueryError message="term query parameter is required." />
  }

  if (!isPositiveInt(params.page)) {
    return <QueryError message="page must be a positive integer." />
  }

  if (!isSortOrder(params.sort)) {
    return <QueryError message="sort must be either 'asc' or 'desc'." />
  }

  return (
    <main>
      <h3>Search Result</h3>
      <p>Term: {params.term}</p>
      <p>Page: {params.page}</p>
      <p>Sort: {params.sort}</p>
      <p>
        <Link to="/challenge05">Back to Challenge 5</Link>
      </p>
    </main>
  )
}

export default SearchPage

