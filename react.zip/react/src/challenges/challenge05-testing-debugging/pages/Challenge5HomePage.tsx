import { useState } from 'react'
import { Link } from 'react-router-dom'
import CommentBox from '../components/CommentBox'

function Challenge5HomePage() {
  const [comments, setComments] = useState<string[]>([])

  return (
    <main>
      <h2>Challenge 5: Testing & Debugging</h2>
      <CommentBox onPost={(value) => setComments((prev) => [...prev, value])} />
      <ul>
        {comments.map((comment, index) => (
          <li key={`${comment}-${index}`}>{comment}</li>
        ))}
      </ul>
      <p>
        "Approved!" test might fail if async state updates are not awaited,
        or if the selector targets stale/incorrect DOM nodes.
      </p>
      <p>
        <Link to="/">Back to Home</Link>
      </p>
    </main>
  )
}

export default Challenge5HomePage
