export interface CommentBoxProps {
  onPost: (value: string) => void
}
