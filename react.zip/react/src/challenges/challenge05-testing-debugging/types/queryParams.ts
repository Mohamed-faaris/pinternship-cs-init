export interface SearchQueryParams {
  term: string
  page: string
  sort: string
}
