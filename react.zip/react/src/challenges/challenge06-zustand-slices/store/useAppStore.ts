import { create } from 'zustand'
import { createNotificationsSlice, type NotificationsSlice } from './notificationsSlice'

export type AppStore = NotificationsSlice

export const useAppStore = create<AppStore>()((...args) => ({
  ...createNotificationsSlice(...args),
}))
