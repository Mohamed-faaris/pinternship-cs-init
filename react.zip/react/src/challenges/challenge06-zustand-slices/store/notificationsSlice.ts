import type { StateCreator } from 'zustand'
import type { NotificationItem } from '../types/notification'

export interface NotificationsSlice {
  notifications: NotificationItem[]
  addNotification: (message: string) => void
  markAsRead: (id: string) => void
  clearNotifications: () => void
}

export const createNotificationsSlice: StateCreator<NotificationsSlice, [], [], NotificationsSlice> = (set) => ({
  notifications: [],
  addNotification: (message) =>
    set((state) => ({
      notifications: [
        ...state.notifications,
        { id: crypto.randomUUID(), message, read: false },
      ],
    })),
  markAsRead: (id) =>
    set((state) => ({
      notifications: state.notifications.map((item) =>
        item.id === id ? { ...item, read: true } : item,
      ),
    })),
  clearNotifications: () => set({ notifications: [] }),
})
