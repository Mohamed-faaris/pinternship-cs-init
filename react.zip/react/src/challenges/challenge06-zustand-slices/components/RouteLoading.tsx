function RouteLoading() {
  return <p>Loading route component...</p>
}

export default RouteLoading
