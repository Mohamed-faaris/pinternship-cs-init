import { useAppStore } from '../store/useAppStore'

function NotificationsPanel() {
  const notifications = useAppStore((state) => state.notifications)
  const addNotification = useAppStore((state) => state.addNotification)
  const markAsRead = useAppStore((state) => state.markAsRead)
  const clearNotifications = useAppStore((state) => state.clearNotifications)

  return (
    <section>
      <h3>Notifications Panel</h3>
      <button type="button" onClick={() => addNotification('New deployment is ready')}>
        Add Notification
      </button>
      <button type="button" onClick={clearNotifications}>
        Clear Notifications
      </button>
      <ul>
        {notifications.map((item) => (
          <li key={item.id}>
            {item.message} ({item.read ? 'read' : 'unread'})
            {!item.read && (
              <button type="button" onClick={() => markAsRead(item.id)}>
                Mark as read
              </button>
            )}
          </li>
        ))}
      </ul>
    </section>
  )
}

export default NotificationsPanel
