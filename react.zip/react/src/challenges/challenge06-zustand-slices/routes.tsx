import { Route, Routes } from 'react-router-dom'
import Challenge6HomePage from './pages/Challenge6HomePage'

function Challenge6Routes() {
  return (
    <Routes>
      <Route path="/" element={<Challenge6HomePage />} />
    </Routes>
  )
}

export default Challenge6Routes
