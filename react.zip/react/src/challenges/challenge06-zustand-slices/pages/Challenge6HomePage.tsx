import { Link } from 'react-router-dom'
import NotificationsPanel from '../components/NotificationsPanel'

function Challenge6HomePage() {
  return (
    <main>
      <h2>Challenge 6: Zustand Slices</h2>
      <NotificationsPanel />
      <p>
        <Link to="/">Back to Home</Link>
      </p>
    </main>
  )
}

export default Challenge6HomePage
