import { Link } from 'react-router-dom'

function HeavyDashboardPage() {
  return (
    <main>
      <h3>Lazy Dashboard</h3>
      <p>This component is loaded only when this route is visited.</p>
      <p>
        <Link to="/challenge06">Back to Challenge 6</Link>
      </p>
    </main>
  )
}

export default HeavyDashboardPage

