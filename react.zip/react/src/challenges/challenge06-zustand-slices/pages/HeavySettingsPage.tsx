import { Link } from 'react-router-dom'

function HeavySettingsPage() {
  return (
    <main>
      <h3>Lazy Settings</h3>
      <p>This component is also lazy-loaded per route.</p>
      <p>
        <Link to="/challenge06">Back to Challenge 6</Link>
      </p>
    </main>
  )
}

export default HeavySettingsPage

