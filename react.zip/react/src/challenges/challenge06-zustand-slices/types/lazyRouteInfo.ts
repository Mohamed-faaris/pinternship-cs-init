export interface LazyRouteInfo {
  path: string
  label: string
}
