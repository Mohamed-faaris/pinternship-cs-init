function PublicPage() {
  return (
    <main>
      <h3>Public page</h3>
      <p>This page is accessible without authentication.</p>
    </main>
  )
}

export default PublicPage
