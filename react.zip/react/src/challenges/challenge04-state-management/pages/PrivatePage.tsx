function PrivatePage() {
  return (
    <main>
      <h3>Private page</h3>
      <p>This page is protected by a route guard.</p>
    </main>
  )
}

export default PrivatePage
