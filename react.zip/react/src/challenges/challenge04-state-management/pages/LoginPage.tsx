import { useNavigate } from 'react-router-dom'
import type { LoginPageProps } from '../types/auth'

function LoginPage({ onLogin }: LoginPageProps) {
  const navigate = useNavigate()

  const handleLogin = () => {
    onLogin()
    navigate('/challenge04/private')
  }

  return (
    <main>
      <h3>Login</h3>
      <button type="button" onClick={handleLogin}>
        Log in and go to private page
      </button>
    </main>
  )
}

export default LoginPage

