import { Link } from 'react-router-dom'
import NotificationList from '../components/NotificationList'
import { useNotificationStore } from '../store/useNotificationStore'

function Challenge4HomePage() {
  const addNotification = useNotificationStore((state) => state.addNotification)
  const clearNotifications = useNotificationStore((state) => state.clearNotifications)

  return (
    <main>
      <h2>Challenge 4: Zustand Store</h2>
      <button type="button" onClick={() => addNotification('Build completed successfully', 'success')}>
        Add Success
      </button>
      <button type="button" onClick={() => addNotification('Server response delayed', 'info')}>
        Add Info
      </button>
      <button type="button" onClick={() => addNotification('Failed to sync data', 'error')}>
        Add Error
      </button>
      <button type="button" onClick={clearNotifications}>
        Clear Notifications
      </button>
      <NotificationList />
      <p>
        <Link to="/">Back to Home</Link>
      </p>
    </main>
  )
}

export default Challenge4HomePage
