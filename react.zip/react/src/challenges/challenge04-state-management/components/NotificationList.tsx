import { useNotificationStore } from '../store/useNotificationStore'

function NotificationList() {
  const notifications = useNotificationStore((state) => state.notifications)
  const unread = notifications.filter((item) => !item.read)
  const markAsRead = useNotificationStore((state) => state.markAsRead)

  return (
    <section>
      <h3>Unread Notifications</h3>
      {unread.length === 0 ? (
        <p>No unread notifications.</p>
      ) : (
        <ul>
          {unread.map((item) => (
            <li key={item.id}>
              <strong>[{item.type}]</strong> {item.message}
              <button type="button" onClick={() => markAsRead(item.id)}>
                Mark as read
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}

export default NotificationList
