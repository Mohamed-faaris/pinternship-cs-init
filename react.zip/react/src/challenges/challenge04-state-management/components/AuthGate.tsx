import { Navigate } from 'react-router-dom'
import type { AuthGateProps } from '../types/auth'

function AuthGate({ isAuthenticated, redirectTo, children }: AuthGateProps) {
  if (!isAuthenticated) {
    return <Navigate to={redirectTo} replace />
  }

  return children
}

export default AuthGate
