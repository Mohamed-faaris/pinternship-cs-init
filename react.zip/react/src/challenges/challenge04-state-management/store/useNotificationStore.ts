import { create } from 'zustand'
import type { NotificationItem, NotificationType } from '../types/notification'

interface NotificationStore {
  notifications: NotificationItem[]
  addNotification: (message: string, type: NotificationType) => void
  markAsRead: (id: string) => void
  clearNotifications: () => void
}

export const useNotificationStore = create<NotificationStore>((set) => ({
  notifications: [],
  addNotification: (message, type) =>
    set((state) => ({
      notifications: [
        ...state.notifications,
        { id: crypto.randomUUID(), message, type, read: false },
      ],
    })),
  markAsRead: (id) =>
    set((state) => ({
      notifications: state.notifications.map((item) =>
        item.id === id ? { ...item, read: true } : item,
      ),
    })),
  clearNotifications: () => set({ notifications: [] }),
}))
