export type NotificationType = 'info' | 'error' | 'success'

export interface NotificationItem {
  id: string
  message: string
  type: NotificationType
  read: boolean
}
