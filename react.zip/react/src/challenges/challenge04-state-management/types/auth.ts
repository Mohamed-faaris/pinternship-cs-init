import type { ReactElement } from 'react'

export interface AuthGateProps {
  isAuthenticated: boolean
  redirectTo: string
  children: ReactElement
}

export interface LoginPageProps {
  onLogin: () => void
}
