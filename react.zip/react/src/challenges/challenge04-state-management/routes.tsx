import { Route, Routes } from 'react-router-dom'
import Challenge4HomePage from './pages/Challenge4HomePage'

function Challenge4Routes() {
  return (
    <Routes>
      <Route path="/" element={<Challenge4HomePage />} />
    </Routes>
  )
}

export default Challenge4Routes
