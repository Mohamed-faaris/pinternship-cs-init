import { Link, useParams } from 'react-router-dom'
import type { DynamicRouteConfig, TopicRouteParams } from '../types/dynamicRoute'

interface TopicPageProps {
  routes: DynamicRouteConfig[]
}

function TopicPage({ routes }: TopicPageProps) {
  const { topicId } = useParams<TopicRouteParams>()

  if (!topicId) {
    return <p>Missing topicId parameter.</p>
  }

  const match = routes.find((route) => route.topicId === topicId)

  if (!match) {
    return (
      <main>
        <h3>Unknown topic</h3>
        <p>No dynamic route matched topicId: {topicId}</p>
        <p>
          <Link to="/challenge08">Back to Challenge 8</Link>
        </p>
      </main>
    )
  }

  return (
    <main>
      <h3>{match.title}</h3>
      <p>{match.summary}</p>
      <p>
        <Link to="/challenge08">Back to Challenge 8</Link>
      </p>
    </main>
  )
}

export default TopicPage

