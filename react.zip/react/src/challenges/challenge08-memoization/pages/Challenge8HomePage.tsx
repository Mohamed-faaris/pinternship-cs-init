import { useCallback, useState } from 'react'
import { Link } from 'react-router-dom'
import TagInput from '../components/TagInput'
import TagList from '../components/TagList'
import type { TagItem } from '../types/tag'

const initialTags: TagItem[] = [
  { id: '1', label: 'react' },
  { id: '2', label: 'typescript' },
  { id: '3', label: 'zustand' },
]

function Challenge8HomePage() {
  const [tags, setTags] = useState<TagItem[]>(initialTags)
  const [filter, setFilter] = useState('')
  const [parentCounter, setParentCounter] = useState(0)

  const addTag = useCallback((value: string) => {
    setTags((current) => [...current, { id: crypto.randomUUID(), label: value }])
  }, [])

  return (
    <main>
      <h2>Challenge 8: Memoization</h2>
      <p>Parent Counter: {parentCounter}</p>
      <button type="button" onClick={() => setParentCounter((count) => count + 1)}>
        Increment Parent Counter
      </button>
      <p>Counter changes should not rerender TagList unless tag/filter props change.</p>

      <TagInput addTag={addTag} />
      <input
        placeholder="Filter tags"
        value={filter}
        onChange={(event) => setFilter(event.target.value)}
      />
      <TagList tags={tags} filter={filter} />

      <p>
        <Link to="/">Back to Home</Link>
      </p>
    </main>
  )
}

export default Challenge8HomePage
