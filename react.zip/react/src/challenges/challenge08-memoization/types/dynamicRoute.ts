export interface DynamicRouteConfig {
  topicId: string
  title: string
  summary: string
}

export interface TopicRouteParams {
  [key: string]: string | undefined
  topicId: string
}
