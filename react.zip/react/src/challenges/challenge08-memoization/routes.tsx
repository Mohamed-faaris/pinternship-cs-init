import { Route, Routes } from 'react-router-dom'
import Challenge8HomePage from './pages/Challenge8HomePage'

function Challenge8Routes() {
  return (
    <Routes>
      <Route path="/" element={<Challenge8HomePage />} />
    </Routes>
  )
}

export default Challenge8Routes
