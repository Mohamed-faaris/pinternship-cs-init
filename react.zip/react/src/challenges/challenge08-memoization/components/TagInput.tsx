import { useState } from 'react'

interface TagInputProps {
  addTag: (value: string) => void
}

function TagInput({ addTag }: TagInputProps) {
  const [value, setValue] = useState('')

  return (
    <div>
      <input
        placeholder="New tag"
        value={value}
        onChange={(event) => setValue(event.target.value)}
      />
      <button
        type="button"
        onClick={() => {
          const trimmed = value.trim()
          if (!trimmed) {
            return
          }
          addTag(trimmed)
          setValue('')
        }}
      >
        Add Tag
      </button>
    </div>
  )
}

export default TagInput
