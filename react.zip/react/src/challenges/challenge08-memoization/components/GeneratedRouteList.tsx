import { Link } from 'react-router-dom'
import type { DynamicRouteConfig } from '../types/dynamicRoute'

interface GeneratedRouteListProps {
  routes: DynamicRouteConfig[]
}

function GeneratedRouteList({ routes }: GeneratedRouteListProps) {
  return (
    <ul>
      {routes.map((route) => (
        <li key={route.topicId}>
          <Link to={`/challenge08/topic/${route.topicId}`}>{route.title}</Link>
        </li>
      ))}
    </ul>
  )
}

export default GeneratedRouteList

