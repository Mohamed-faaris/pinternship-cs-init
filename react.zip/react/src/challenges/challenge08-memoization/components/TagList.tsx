import { memo, useMemo } from 'react'
import type { TagItem } from '../types/tag'

interface TagListProps {
  tags: TagItem[]
  filter: string
}

function TagListComponent({ tags, filter }: TagListProps) {
  const filteredTags = useMemo(
    () => tags.filter((tag) => tag.label.toLowerCase().includes(filter.toLowerCase())),
    [tags, filter],
  )

  return (
    <section>
      <h3>Tag List</h3>
      <ul>
        {filteredTags.map((tag) => (
          <li key={tag.id}>{tag.label}</li>
        ))}
      </ul>
    </section>
  )
}

const TagList = memo(TagListComponent)

export default TagList
