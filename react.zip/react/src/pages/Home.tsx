import { Link } from 'react-router-dom'

interface ChallengeLink {
  id: number
  title: string
  path: string
}

const challengeLinks: ChallengeLink[] = [
  { id: 1, title: 'tsx-typed-components', path: '/challenge01' },
  { id: 2, title: 'tsx-type-safety', path: '/challenge02' },
  { id: 3, title: 'routing', path: '/challenge03' },
  { id: 4, title: 'state-management', path: '/challenge04' },
  { id: 5, title: 'testing-debugging', path: '/challenge05' },
  { id: 6, title: 'zustand-slices', path: '/challenge06' },
  { id: 7, title: 'advanced-zustand', path: '/challenge07' },
  { id: 8, title: 'memoization', path: '/challenge08' },
  { id: 9, title: 'lazy-loading', path: '/challenge09' },
  { id: 10, title: 'bundle-analysis', path: '/challenge10' },
]

function Home() {
  return (
    <main>
      <h1>React Routing Challenges</h1>
      <p>Choose a challenge:</p>
      <ul>
        {challengeLinks.map((challenge) => (
          <li key={challenge.id}>
            <Link to={challenge.path}>
              Challenge {challenge.id}: {challenge.title}
            </Link>
          </li>
        ))}
      </ul>
    </main>
  )
}

export default Home

