import { Suspense, lazy } from 'react'
import { BrowserRouter, Link, Navigate, Route, Routes } from 'react-router-dom'
import Home from '../pages/Home'

const Challenge1Routes = lazy(() => import('../challenges/challenge01-tsx-typed-components/routes'))
const Challenge2Routes = lazy(() => import('../challenges/challenge02-tsx-type-safety/routes'))
const Challenge3Routes = lazy(() => import('../challenges/challenge03-routing/routes'))
const Challenge4Routes = lazy(() => import('../challenges/challenge04-state-management/routes'))
const Challenge5Routes = lazy(() => import('../challenges/challenge05-testing-debugging/routes'))
const Challenge6Routes = lazy(() => import('../challenges/challenge06-zustand-slices/routes'))
const Challenge7Routes = lazy(() => import('../challenges/challenge07-advanced-zustand/routes'))
const Challenge8Routes = lazy(() => import('../challenges/challenge08-memoization/routes'))
const Challenge9Routes = lazy(() => import('../challenges/challenge09-lazy-loading/routes'))
const Challenge10Routes = lazy(() => import('../challenges/challenge10-bundle-analysis/routes'))

function NotFound() {
  return (
    <main>
      <h2>Page not found</h2>
      <p>
        Return to <Link to="/">Home</Link>.
      </p>
    </main>
  )
}

function AppRouter() {
  return (
    <BrowserRouter>
      <Suspense fallback={<main><p>Loading challenge...</p></main>}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/challenge01/*" element={<Challenge1Routes />} />
          <Route path="/challenge02/*" element={<Challenge2Routes />} />
          <Route path="/challenge03/*" element={<Challenge3Routes />} />
          <Route path="/challenge04/*" element={<Challenge4Routes />} />
          <Route path="/challenge05/*" element={<Challenge5Routes />} />
          <Route path="/challenge06/*" element={<Challenge6Routes />} />
          <Route path="/challenge07/*" element={<Challenge7Routes />} />
          <Route path="/challenge08/*" element={<Challenge8Routes />} />
          <Route path="/challenge09/*" element={<Challenge9Routes />} />
          <Route path="/challenge10/*" element={<Challenge10Routes />} />
          <Route path="/home" element={<Navigate to="/" replace />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
    </BrowserRouter>
  )
}

export default AppRouter
